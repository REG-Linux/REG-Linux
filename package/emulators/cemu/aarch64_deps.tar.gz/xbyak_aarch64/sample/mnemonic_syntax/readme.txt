This directory contains sample of mnemonic function syntax.
