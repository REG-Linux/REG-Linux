#include "defs.h"
#include <libucontext/libucontext.h>
#include "common-trampoline.c"
